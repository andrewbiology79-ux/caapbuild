# 0.2.36 – "Canvas: trying to use a recycled bitmap" fix
Cause: MediaThumbnail (and ImagePreviewDialog / ImageEditDialog) called Bitmap.recycle() on dispose/replace while Compose still drew the bitmap on the render thread.
Fix: removed all recycle() calls in UI composables; bitmaps are freed by GC. (Pipeline/PDF-export recycle of private temp bitmaps is unchanged.)
Files: EditorImageAttachments.kt, ImagePreviewDialog.kt, ImageEditDialog.kt
Also contains 0.2.35 (FlowRow in EdThumbnail, no nested horizontal scroll).

# 0.2.37 – hardening
- MediaThumbnail: decode wrapped in try/catch (incl. OutOfMemoryError) so a bad/huge file shows "ছবি অনুপলব্ধ" instead of crashing.
- EdStimulusImages: each thumbnail wrapped in key(imageId) so adding/removing/reordering never reuses another image's state.

# 0.2.38 – image layout like the old app
- Picture is larger (full picture visible, Fit), fixed-width card; red cross at the corner removes it; tapping the picture opens the large preview.
- Under the picture, one line: replace, save (export), edit. The separate "large preview" button and the stimulus top/bottom + left/right buttons were removed.

# 0.2.39 – image edit crop bars
Each crop edge (উপর/নিচ/বাম/ডান) now has a fine slider (0.1% steps, like the old app's bar) plus a box beside it to type an exact value (e.g. 12.5). Slider and box stay in sync; opposite-edge limit (max 90% total) still applies.
File: ImageEditDialog.kt (CropRow)

# 0.2.40 – crop: finer and no limit
Crop edges now go 0–100% each, independently (no 90% total cap), in 0.01% steps (slider and typed box). If edges overlap, at least 1 px is kept so the picture never becomes empty.

# 0.2.41 – crop − / + buttons
Each crop edge keeps its slider and typed box and now also has − and + buttons around the box (one tap = 0.01%).

# 0.2.42 – resize dropdown in image edit window
Ribbon under the title shows the current resolution (W×H of the live preview) and a resize dropdown: "রিসাইজ নেই", 1024×350, 1024×400, then "+ নতুন মাপ যোগ করুন" (width/height, 1–2048 px). Added sizes are saved (SharedPreferences image_edit_prefs) and listed next time. Resize scales the whole picture to exactly the chosen size after rotate/crop/scan (stretch allowed, no cropping).

# 0.2.43 – editor image / crop / LaTeX toolbar UI (Type CQ add, Type CQ edit, Chapter CQ – all share the same components)
- Image edit window: the whole picture now stays still while a crop bar is dragged; only the part that will be cut off is shaded (top / bottom / left / right) with a frame around the kept part. The size text (W×H) still shows the real result. The typed crop boxes and − / + buttons are smaller (box 52×28 dp, buttons 26 dp).
- Minimum editor: a picture is shown small (112×80 dp) with only the red cross button; the replace button is not shown. Full editor: pictures are smaller (150×104 dp) with replace / export / edit under them.
- LaTeX toolbar: closed by default; a small ∑ switch at the left of the toolbar strip opens / closes it (every text box that has the toolbar).
- Stimulus pictures under the question text: the add-picture button stays pinned at the far top-right corner of the strip; pictures are added one after another on its left.
- Not changed on purpose: the "ছবি অনুপলব্ধ after reopening the app" problem (to be handled separately).
Files: ImageEditDialog.kt, EditorDesign.kt, app/build.gradle.kts (versionCode 48 / 0.2.43-editor-ui)
NOT compiled or run here (no Gradle/Kotlin in this environment) – run CI before use.

# 0.2.44 – image edit window: scan mode before crop, undo / redo
- Order of work is now rotate -> scan mode (grey / black-and-white) on the WHOLE picture -> crop -> resize. Choosing black-and-white turns the picture itself black-and-white, and cropping cuts that black-and-white picture, so the saved result is exactly what the crop preview shows (before, the scan was applied to the cropped part only). The base picture (rotate + scan) is made once per rotation / scan change; crop and resize are cheap steps on top of it.
- Ribbon (under the title): ↶ undo and ↷ redo buttons at the left, then the size text, then the resize dropdown. Undo / redo cover rotate, crop (all four edges), scan mode and resize. Dragging a bar or typing a number counts as one step (stored when the controls are still for a moment, or when Undo / Redo is pressed). A new edit after an undo clears the redo steps.
Files: ImageEditDialog.kt, app/build.gradle.kts (versionCode 49 / 0.2.44-crop-scan-undo)
NOT compiled or run here (no Gradle/Kotlin in this environment) – run CI before use.
